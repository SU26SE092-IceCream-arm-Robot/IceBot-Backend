using Domain.Common;
using Domain.Identity.Entities;

namespace Domain.Entities;

public partial class RobotProgram : RobotConfigurationEntity
{
    public Guid? OrganizationId { get; set; }

    public Guid? StoreId { get; set; }

    public Guid? KioskId { get; set; }

    public Guid? DeviceId { get; set; }

    public Guid? TemplateProgramId { get; set; }

    public Guid? CalibratedByAccountId { get; set; }

    public string Code { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string ScopeType { get; set; } = "Global";

    public string ProductType { get; set; } = "IceCream";

    public int ProgramVersion { get; set; } = 1;

    public string Status { get; set; } = "Draft";

    public string Vendor { get; set; } = "Farino";

    public string? VendorProgramId { get; set; }

    public string? VendorProgramVersion { get; set; }

    public long? SupportedDeviceTypeId { get; set; }

    public int? EstimatedDurationSeconds { get; set; }

    public bool IsDefault { get; set; }

    public string CalibrationStatus { get; set; } = "NotRequired";

    public string? Description { get; set; }

    public string? ProgramPayloadJson { get; set; }

    public string? CalibrationDataJson { get; set; }

    public string? SafetyZoneJson { get; set; }

    public DateTimeOffset? EffectiveFrom { get; set; }

    public DateTimeOffset? EffectiveTo { get; set; }

    public DateTimeOffset? PublishedAt { get; set; }

    public DateTimeOffset? CalibratedAt { get; set; }

    public DateTimeOffset? ActivatedAt { get; set; }

    public DateTimeOffset? RetiredAt { get; set; }

    public virtual Organization? Organization { get; set; }

    public virtual Store? Store { get; set; }

    public virtual Kiosk? Kiosk { get; set; }

    public virtual Device? Device { get; set; }

    public virtual RobotProgram? TemplateProgram { get; set; }

    public virtual Account? CalibratedByAccount { get; set; }

    public virtual ICollection<RobotProgram> DerivedPrograms { get; set; } = new List<RobotProgram>();

    public virtual ICollection<RobotJob> RobotJobs { get; set; } = new List<RobotJob>();

    public virtual ICollection<RobotProgramStep> RobotProgramSteps { get; set; } = new List<RobotProgramStep>();

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
