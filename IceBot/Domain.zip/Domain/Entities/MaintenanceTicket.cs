using Domain.Common;
using Domain.Identity.Entities;

namespace Domain.Entities;

public partial class MaintenanceTicket : RobotRuntimeAggregateEntity
{
    public Guid KioskId { get; set; }

    public Guid? DeviceId { get; set; }

    public Guid? AssignedToAccountId { get; set; }

    public string TicketNumber { get; set; } = null!;

    public string IssueCode { get; set; } = null!;

    public string Title { get; set; } = null!;

    public string? Description { get; set; }

    public string Priority { get; set; } = "Medium";

    public string Status { get; set; } = "Open";

    public DateTimeOffset ReportedAt { get; set; }

    public DateTimeOffset? DueAt { get; set; }

    public DateTimeOffset? ResolvedAt { get; set; }

    public DateTimeOffset? ClosedAt { get; set; }

    public string? ResolutionNotes { get; set; }

    public virtual Account? AssignedToAccount { get; set; }

    public virtual Account? CreatedByAccount { get; set; }

    public virtual Device? Device { get; set; }

    public virtual Kiosk Kiosk { get; set; } = null!;
}
