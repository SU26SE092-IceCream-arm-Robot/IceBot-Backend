using Domain.Common;

namespace Domain.Entities;

public partial class Device : BusinessEntity
{
    public long DeviceTypeId { get; set; }

    public Guid? DeviceModelId { get; set; }

    public Guid? KioskId { get; set; }

    public string Code { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string? SerialNumber { get; set; }

    public string Status { get; set; } = "Provisioning";

    public string? PositionLabel { get; set; }

    public string? FirmwareVersion { get; set; }

    public DateTimeOffset? InstalledAt { get; set; }

    public DateTimeOffset? LastSeenAt { get; set; }

    public string? MetadataJson { get; set; }

    public virtual ICollection<DeviceEvent> DeviceEvents { get; set; } = new List<DeviceEvent>();

    public virtual DeviceModel? DeviceModel { get; set; }

    public virtual DeviceType DeviceType { get; set; } = null!;

    public virtual ICollection<IngredientDispenserState> IngredientDispenserStates { get; set; } = new List<IngredientDispenserState>();

    public virtual Kiosk? Kiosk { get; set; }

    public virtual ICollection<RobotProgram> RobotPrograms { get; set; } = new List<RobotProgram>();

    public virtual ICollection<RobotJob> RobotJobs { get; set; } = new List<RobotJob>();
}
