using Domain.Common;
using Domain.Identity.Entities;

namespace Domain.Entities;

public partial class StockMovement : RobotRuntimeEventEntity
{
    public Guid IngredientDispenserStateId { get; set; }

    public Guid? KioskId { get; set; }

    public Guid? DeviceId { get; set; }

    public Guid? IngredientId { get; set; }

    public Guid? SourceEventId { get; set; }

    public Guid? CorrelationId { get; set; }

    public Guid? CausationId { get; set; }

    public string MovementType { get; set; } = null!;

    public decimal Quantity { get; set; }

    public decimal? BalanceAfter { get; set; }

    public string Unit { get; set; } = "gram";

    public string? ReasonCode { get; set; }

    public string? ReferenceType { get; set; }

    public Guid? ReferenceId { get; set; }

    public string? Notes { get; set; }

    public DateTimeOffset OccurredAt { get; set; }

    public virtual Account? CreatedByAccount { get; set; }

    public virtual Kiosk? Kiosk { get; set; }

    public virtual Device? Device { get; set; }

    public virtual Ingredient? Ingredient { get; set; }

    public virtual IngredientDispenserState IngredientDispenserState { get; set; } = null!;
}
