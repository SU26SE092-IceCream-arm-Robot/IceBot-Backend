using Domain.Common;

namespace Domain.Entities;

public partial class RobotJob : RobotRuntimeAggregateEntity
{
    public Guid OrderId { get; set; }

    public Guid? OrderItemId { get; set; }

    public Guid KioskId { get; set; }

    public Guid? RobotProgramId { get; set; }

    public Guid? DeviceId { get; set; }

    public Guid? RecipeId { get; set; }

    public string JobNumber { get; set; } = null!;

    public string? IdempotencyKey { get; set; }

    public Guid? ProductionRequestId { get; set; }

    public Guid? CorrelationId { get; set; }

    public string Status { get; set; } = "Queued";

    public int Priority { get; set; }

    public string? ProductCode { get; set; }

    public int? RecipeVersion { get; set; }

    public string? RecipeSnapshotJson { get; set; }

    public DateTimeOffset RequestedAt { get; set; }

    public DateTimeOffset? StartedAt { get; set; }

    public DateTimeOffset? CompletedAt { get; set; }

    public DateTimeOffset? FailedAt { get; set; }

    public string? FailureCode { get; set; }

    public string? FailureMessage { get; set; }

    public int RetryCount { get; set; }

    public int MaxRetries { get; set; } = 1;

    public DateTimeOffset? NextRetryAt { get; set; }

    public string? LastErrorCode { get; set; }

    public string? LastErrorMessage { get; set; }

    public virtual Device? Device { get; set; }

    public virtual Kiosk Kiosk { get; set; } = null!;

    public virtual Order Order { get; set; } = null!;

    public virtual OrderItem? OrderItem { get; set; }

    public virtual Recipe? Recipe { get; set; }

    public virtual ICollection<DeviceEvent> DeviceEvents { get; set; } = new List<DeviceEvent>();

    public virtual ICollection<RobotJobEvent> RobotJobEvents { get; set; } = new List<RobotJobEvent>();

    public virtual ICollection<RobotJobStep> RobotJobSteps { get; set; } = new List<RobotJobStep>();

    public virtual RobotProgram? RobotProgram { get; set; }
}
