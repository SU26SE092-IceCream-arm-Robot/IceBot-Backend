using Domain.Common;

namespace Domain.Entities;

public partial class IngredientDispenserState : RobotRuntimeAggregateEntity
{
    public Guid DeviceId { get; set; }

    public Guid? KioskId { get; set; }

    public Guid IngredientId { get; set; }

    public string ContainerCode { get; set; } = null!;

    public decimal CurrentQuantity { get; set; }

    public decimal CapacityQuantity { get; set; }

    public string Unit { get; set; } = "gram";

    public decimal? LowThreshold { get; set; }

    public decimal? CriticalThreshold { get; set; }

    public string? CurrentLevelStatus { get; set; }

    public DateTimeOffset LastMeasuredAt { get; set; }

    public DateTimeOffset? LastRefilledAt { get; set; }

    public DateTimeOffset? ExpiresAt { get; set; }

    public string? SensorPayloadJson { get; set; }

    public virtual Device Device { get; set; } = null!;

    public virtual Kiosk? Kiosk { get; set; }

    public virtual Ingredient Ingredient { get; set; } = null!;

    public virtual ICollection<StockMovement> StockMovements { get; set; } = new List<StockMovement>();
}
