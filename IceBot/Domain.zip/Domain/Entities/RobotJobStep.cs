using Domain.Common;

namespace Domain.Entities;

public partial class RobotJobStep : RobotRuntimeAggregateEntity
{
    public Guid RobotJobId { get; set; }

    public Guid? RobotProgramStepId { get; set; }

    public int StepNumber { get; set; }

    public string StepCode { get; set; } = null!;

    public string Command { get; set; } = null!;

    public string? ParametersJson { get; set; }

    public string Status { get; set; } = "Pending";

    public DateTimeOffset? StartedAt { get; set; }

    public DateTimeOffset? CompletedAt { get; set; }

    public DateTimeOffset? FailedAt { get; set; }

    public int? DurationMs { get; set; }

    public int RetryCount { get; set; }

    public int MaxRetries { get; set; } = 3;

    public DateTimeOffset? NextRetryAt { get; set; }

    public string? LastErrorCode { get; set; }

    public string? LastErrorMessage { get; set; }

    public virtual RobotJob RobotJob { get; set; } = null!;

    public virtual ICollection<RobotJobEvent> RobotJobEvents { get; set; } = new List<RobotJobEvent>();

    public virtual RobotProgramStep? RobotProgramStep { get; set; }
}
