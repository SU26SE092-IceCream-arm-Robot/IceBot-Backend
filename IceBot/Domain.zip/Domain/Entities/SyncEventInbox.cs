using Domain.Common;

namespace Domain.Entities;

public partial class SyncEventInbox : GuidEntity
{
    public Guid EventId { get; set; }

    public Guid? KioskId { get; set; }

    public Guid SourceNodeId { get; set; }

    public Guid? CorrelationId { get; set; }

    public Guid? CausationId { get; set; }

    public string EventType { get; set; } = null!;

    public string? AggregateType { get; set; }

    public Guid? AggregateId { get; set; }

    public string PayloadJson { get; set; } = null!;

    public string? HeadersJson { get; set; }

    public string Status { get; set; } = "Received";

    public DateTimeOffset OccurredAt { get; set; }

    public DateTimeOffset ReceivedAt { get; set; }

    public DateTimeOffset? ProcessedAt { get; set; }

    public DateTimeOffset? LastAttemptAt { get; set; }

    public DateTimeOffset? NextRetryAt { get; set; }

    public Guid? LockId { get; set; }

    public DateTimeOffset? LockedUntil { get; set; }

    public int ProcessingAttempts { get; set; }

    public int MaxProcessingAttempts { get; set; } = 5;

    public string? LastError { get; set; }

    public virtual Kiosk? Kiosk { get; set; }
}
