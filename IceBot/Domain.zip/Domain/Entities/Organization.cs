using Domain.Common;

namespace Domain.Entities;

public partial class Organization : BusinessEntity
{
    public string Code { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string? LegalName { get; set; }

    public string? TaxCode { get; set; }

    public string? Email { get; set; }

    public string? PhoneNumber { get; set; }

    public string? Address { get; set; }

    public string Status { get; set; } = "Active";

    public string? MetadataJson { get; set; }

    public virtual ICollection<RobotProgram> RobotPrograms { get; set; } = new List<RobotProgram>();

    public virtual ICollection<Store> Stores { get; set; } = new List<Store>();
}
