using Domain.Common;
using Domain.Identity.Entities;

namespace Domain.Entities;

public partial class RobotProgramStep : RobotConfigurationEntity
{
    public Guid RobotProgramId { get; set; }

    public Guid? TemplateStepId { get; set; }

    public Guid? CalibratedByAccountId { get; set; }

    public int StepNumber { get; set; }

    public string StepCode { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Command { get; set; } = null!;

    public string? ParametersJson { get; set; }

    public string? ParametersOverrideJson { get; set; }

    public bool RequiresCalibration { get; set; }

    public string? CalibrationKey { get; set; }

    public string CalibrationStatus { get; set; } = "NotRequired";

    public string? CoordinateFrame { get; set; }

    public string? ToolName { get; set; }

    public decimal? TargetX { get; set; }

    public decimal? TargetY { get; set; }

    public decimal? TargetZ { get; set; }

    public decimal? TargetRx { get; set; }

    public decimal? TargetRy { get; set; }

    public decimal? TargetRz { get; set; }

    public decimal? OffsetX { get; set; }

    public decimal? OffsetY { get; set; }

    public decimal? OffsetZ { get; set; }

    public decimal? SpeedScale { get; set; }

    public decimal? SafetyClearanceMm { get; set; }

    public int? ExpectedDurationMs { get; set; }

    public string? RetryPolicyJson { get; set; }

    public bool IsRequired { get; set; } = true;

    public int? NextOnSuccessStepNumber { get; set; }

    public int? NextOnFailureStepNumber { get; set; }

    public string? CalibrationDataJson { get; set; }

    public string? ValidationResultJson { get; set; }

    public DateTimeOffset? CalibratedAt { get; set; }

    public DateTimeOffset? ValidatedAt { get; set; }

    public virtual RobotProgramStep? TemplateStep { get; set; }

    public virtual Account? CalibratedByAccount { get; set; }

    public virtual ICollection<RobotProgramStep> DerivedSteps { get; set; } = new List<RobotProgramStep>();

    public virtual ICollection<RobotJobStep> RobotJobSteps { get; set; } = new List<RobotJobStep>();

    public virtual RobotProgram RobotProgram { get; set; } = null!;
}
