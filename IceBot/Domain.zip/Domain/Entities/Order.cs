using Domain.Common;
using Domain.Payments.Entities;

namespace Domain.Entities;

public partial class Order : BusinessEntity
{
    public Guid KioskId { get; set; }

    public Guid? StoreId { get; set; }

    public string OrderNumber { get; set; } = null!;

    public string? IdempotencyKey { get; set; }

    public string? ClientOrderId { get; set; }

    public Guid? CorrelationId { get; set; }

    public string Channel { get; set; } = "Tablet";

    public string Status { get; set; } = "Draft";

    public string PaymentStatus { get; set; } = "Unpaid";

    public string Currency { get; set; } = "VND";

    public decimal SubtotalAmount { get; set; }

    public decimal DiscountAmount { get; set; }

    public decimal TaxAmount { get; set; }

    public decimal TotalAmount { get; set; }

    public decimal PaidAmount { get; set; }

    public string? CustomerName { get; set; }

    public string? CustomerPhoneNumber { get; set; }

    public DateTimeOffset PlacedAt { get; set; }

    public DateTimeOffset? PaidAt { get; set; }

    public DateTimeOffset? CompletedAt { get; set; }

    public DateTimeOffset? CancelledAt { get; set; }

    public string? Notes { get; set; }

    public virtual Kiosk Kiosk { get; set; } = null!;

    public virtual Store? Store { get; set; }

    public virtual ICollection<OperationLog> OperationLogs { get; set; } = new List<OperationLog>();

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    public virtual ICollection<OrderStatusHistory> OrderStatusHistories { get; set; } = new List<OrderStatusHistory>();

    public virtual ICollection<PaymentTransaction> PaymentTransactions { get; set; } = new List<PaymentTransaction>();

    public virtual ICollection<RobotJob> RobotJobs { get; set; } = new List<RobotJob>();
}
