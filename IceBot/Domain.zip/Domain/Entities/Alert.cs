using Domain.Common;
using Domain.Identity.Entities;

namespace Domain.Entities;

public partial class Alert : RobotRuntimeAggregateEntity
{
    public Guid KioskId { get; set; }

    public Guid? DeviceId { get; set; }

    public Guid? RobotJobId { get; set; }

    public Guid? AcknowledgedByAccountId { get; set; }

    public string AlertCode { get; set; } = null!;

    public string Severity { get; set; } = "Warning";

    public string Title { get; set; } = null!;

    public string? Message { get; set; }

    public string Status { get; set; } = "Open";

    public string? SourceType { get; set; }

    public Guid? SourceId { get; set; }

    public DateTimeOffset RaisedAt { get; set; }

    public DateTimeOffset? AcknowledgedAt { get; set; }

    public DateTimeOffset? ResolvedAt { get; set; }

    public string? ResolutionNotes { get; set; }

    public virtual Account? AcknowledgedByAccount { get; set; }

    public virtual Device? Device { get; set; }

    public virtual RobotJob? RobotJob { get; set; }

    public virtual Kiosk Kiosk { get; set; } = null!;
}
