using Domain.Common;
using Domain.Identity.Entities;

namespace Domain.Entities;

public partial class OrderStatusHistory : BusinessEntity
{
    public Guid OrderId { get; set; }

    public Guid? ChangedByAccountId { get; set; }

    public string? FromStatus { get; set; }

    public string ToStatus { get; set; } = null!;

    public string? Reason { get; set; }

    public DateTimeOffset ChangedAt { get; set; }

    public virtual Account? ChangedByAccount { get; set; }

    public virtual Order Order { get; set; } = null!;
}
