using Domain.Common;

namespace Domain.Payments.Entities;

public partial class PaymentCallback : AppendOnlyEntity
{
    public Guid PaymentTransactionId { get; set; }

    public string Provider { get; set; } = null!;

    public string EventType { get; set; } = null!;

    public string? ProviderEventId { get; set; }

    public string PayloadJson { get; set; } = null!;

    public string? Signature { get; set; }

    public string ProcessingStatus { get; set; } = "Received";

    public int ProcessingAttempts { get; set; }

    public int MaxProcessingAttempts { get; set; } = 5;

    public DateTimeOffset ReceivedAt { get; set; }

    public DateTimeOffset? LastAttemptAt { get; set; }

    public DateTimeOffset? NextRetryAt { get; set; }

    public DateTimeOffset? ProcessedAt { get; set; }

    public string? LastError { get; set; }

    public virtual PaymentTransaction PaymentTransaction { get; set; } = null!;
}
