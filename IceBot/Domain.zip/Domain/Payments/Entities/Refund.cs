using Domain.Common;
using Domain.Identity.Entities;

namespace Domain.Payments.Entities;

public partial class Refund : BusinessEntity
{
    public Guid PaymentTransactionId { get; set; }

    public Guid? RequestedByAccountId { get; set; }

    public string RefundNumber { get; set; } = null!;

    public string? IdempotencyKey { get; set; }

    public Guid? CorrelationId { get; set; }

    public string? ProviderRefundId { get; set; }

    public decimal Amount { get; set; }

    public string Currency { get; set; } = "VND";

    public string Reason { get; set; } = null!;

    public string Status { get; set; } = "Requested";

    public DateTimeOffset RequestedAt { get; set; }

    public DateTimeOffset? ProcessedAt { get; set; }

    public DateTimeOffset? RejectedAt { get; set; }

    public int RetryCount { get; set; }

    public int MaxRetries { get; set; } = 3;

    public DateTimeOffset? NextRetryAt { get; set; }

    public DateTimeOffset? LastAttemptAt { get; set; }

    public string? LastErrorCode { get; set; }

    public string? LastErrorMessage { get; set; }

    public virtual PaymentTransaction PaymentTransaction { get; set; } = null!;

    public virtual Account? RequestedByAccount { get; set; }
}
