using Domain.Common;
using Domain.Entities;

namespace Domain.Payments.Entities;

public partial class PaymentTransaction : BusinessEntity
{
    public Guid OrderId { get; set; }

    public long PaymentMethodId { get; set; }

    public string TransactionNumber { get; set; } = null!;

    public string? IdempotencyKey { get; set; }

    public Guid? CorrelationId { get; set; }

    public string Provider { get; set; } = null!;

    public string? ProviderTransactionId { get; set; }

    public string? PaymentIntentId { get; set; }

    public decimal Amount { get; set; }

    public string Currency { get; set; } = "VND";

    public string Status { get; set; } = "Pending";

    public DateTimeOffset RequestedAt { get; set; }

    public DateTimeOffset? AuthorizedAt { get; set; }

    public DateTimeOffset? PaidAt { get; set; }

    public DateTimeOffset? FailedAt { get; set; }

    public DateTimeOffset? CancelledAt { get; set; }

    public int RetryCount { get; set; }

    public int MaxRetries { get; set; } = 3;

    public DateTimeOffset? NextRetryAt { get; set; }

    public DateTimeOffset? LastAttemptAt { get; set; }

    public string? LastErrorCode { get; set; }

    public string? LastErrorMessage { get; set; }

    public string? FailureCode { get; set; }

    public string? FailureMessage { get; set; }

    public string? RawRequestJson { get; set; }

    public string? RawResponseJson { get; set; }

    public virtual Order Order { get; set; } = null!;

    public virtual ICollection<PaymentCallback> PaymentCallbacks { get; set; } = new List<PaymentCallback>();

    public virtual PaymentMethod PaymentMethod { get; set; } = null!;

    public virtual ICollection<Refund> Refunds { get; set; } = new List<Refund>();
}
